/* ============================================================
   draw.js — All Canvas Drawing Functions
   ============================================================ */

const GROUND = 150;

/** HSL rainbow colour based on a time value */
function rainbowColor(t) {
  return `hsl(${t * 3 % 360}, 90%, 65%)`;
}

// ── BACKGROUND & SCENERY ─────────────────────────────────────

function drawScene(ctx, frame, rainbowMode, rainbowT, bunX, bunY, invincible) {
  const W = 640, H = 185;

  // Screen flash (handled in game.js via screenFlash counter)
  // Sky gradient
  const skyGrd = ctx.createLinearGradient(0, 0, 0, GROUND);
  if (rainbowMode && rainbowT > 0) {
    skyGrd.addColorStop(0, `hsl(${frame * 2 % 360}, 70%, 92%)`);
    skyGrd.addColorStop(1, `hsl(${(frame * 2 + 120) % 360}, 60%, 96%)`);
  } else {
    skyGrd.addColorStop(0, "#FFF5FD");
    skyGrd.addColorStop(1, "#FFF0FA");
  }
  ctx.fillStyle = skyGrd;
  ctx.fillRect(0, 0, W, H);

  // Clouds
  const t = frame * 0.005;
  drawCloud(ctx,  90 + Math.sin(t)       * 10, 30, 27);
  drawCloud(ctx, 300 + Math.sin(t + 1)   *  8, 20, 21);
  drawCloud(ctx, 510 + Math.sin(t + 2)   *  9, 28, 25);

  // Ground
  ctx.fillStyle = "#FFD6EE";
  ctx.fillRect(0, GROUND, W, 35);
  ctx.fillStyle = "#F0A0D0";
  ctx.fillRect(0, GROUND, W, 3);

  // Scrolling flowers
  ctx.font = "13px serif";
  for (let i = 0; i < 10; i++) {
    const fx = (frame * 1.3 + i * 72) % 680;
    ctx.fillText("✿", fx, GROUND - 11);
  }

  // Background stars
  [[120, 52], [248, 40], [372, 48], [508, 36]].forEach(([sx, sy], i) => {
    ctx.fillStyle = rainbowMode
      ? rainbowColor(sx + frame)
      : ["#FFD6EE", "#D6EEFF", "#D6FFE8", "#FFE8D6"][i];
    ctx.font = "15px serif";
    ctx.fillText("★", sx, sy + Math.sin(frame * 0.05 + i * 1.2) * 5);
  });

  // Invincibility orbiting sparkles
  if (invincible) {
    for (let i = 0; i < 4; i++) {
      const angle  = frame * 0.1 + i * Math.PI / 2;
      const radius = 28;
      ctx.fillStyle = rainbowColor(frame + i * 30);
      ctx.font = "10px serif";
      ctx.fillText("✦",
        bunX + Math.cos(angle) * radius,
        bunY - 12 + Math.sin(angle) * radius
      );
    }
  }
}

function drawCloud(ctx, x, y, s) {
  ctx.fillStyle = "#FFE8F8";
  [[0, 0, 0.6], [s * 0.5, s * 0.2, 0.45], [s * -0.4, s * 0.25, 0.35], [s * 0.1, s * 0.38, 0.5]]
    .forEach(([dx, dy, r]) => {
      ctx.beginPath();
      ctx.arc(x + dx, y + dy, s * r, 0, Math.PI * 2);
      ctx.fill();
    });
}

// ── BUN CHARACTER ────────────────────────────────────────────

function drawBun(ctx, x, y, frame, jumping, shakingBun, shakeT, invincible, doubleScore) {
  ctx.save();
  ctx.translate(x, y);

  // Shake effect on hit
  if (shakingBun) ctx.translate(Math.sin(shakeT * 4) * 10, 0);

  // Squash & stretch
  const sq = jumping ? 0.82 : 1 + Math.sin(frame * 0.24) * 0.015;
  ctx.scale(sq, 1 / sq);

  // Glow effects
  if (invincible)       { ctx.shadowColor = "#FFD700"; ctx.shadowBlur = 18; }
  else if (doubleScore) { ctx.shadowColor = "#FDD835"; ctx.shadowBlur = 10; }

  // Body
  ctx.fillStyle = invincible ? rainbowColor(frame) : "#F8BBD9";
  ctx.beginPath(); ctx.ellipse(0, -10, 18, 15, 0, 0, Math.PI * 2); ctx.fill();

  // Ears (outer)
  ctx.fillStyle = "#F48FB1";
  ctx.beginPath(); ctx.ellipse(-9, -22, 6, 10, -0.3, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.ellipse( 9, -22, 6, 10,  0.3, 0, Math.PI * 2); ctx.fill();

  // Ears (inner)
  ctx.fillStyle = "#FCE4EC";
  ctx.beginPath(); ctx.ellipse(-9, -22, 3.5, 6.5, -0.3, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.ellipse( 9, -22, 3.5, 6.5,  0.3, 0, Math.PI * 2); ctx.fill();

  ctx.shadowBlur = 0;

  // Eyes
  ctx.fillStyle = "#880050";
  ctx.beginPath(); ctx.arc(-6, -12, 2.5, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.arc( 6, -12, 2.5, 0, Math.PI * 2); ctx.fill();

  // Eye shine
  ctx.fillStyle = "#fff";
  ctx.beginPath(); ctx.arc(-5, -13, 1, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.arc( 7, -13, 1, 0, Math.PI * 2); ctx.fill();

  // Smile
  ctx.strokeStyle = "#F48FB1"; ctx.lineWidth = 1.5;
  ctx.beginPath(); ctx.arc(0, -6, 4, 0.2, Math.PI - 0.2); ctx.stroke();

  // Legs (animated while running)
  const leg = jumping ? -6 : Math.sin(frame * 0.22) * 6;
  ctx.fillStyle = "#F48FB1";
  ctx.beginPath(); ctx.ellipse(-7,  4 + leg, 5, 8,  0.2, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.ellipse( 7,  4 - leg, 5, 8, -0.2, 0, Math.PI * 2); ctx.fill();

  // Jump shadow
  if (jumping) {
    ctx.fillStyle = "rgba(255,180,220,0.28)";
    ctx.beginPath();
    ctx.ellipse(0, GROUND - y, 16, 5, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();
}

// ── OBSTACLES ────────────────────────────────────────────────

function drawObstacle(ctx, ob) {
  const { x, w, h, color } = ob;
  const y = GROUND - h;
  const r = 5;

  // Gradient fill
  const grd = ctx.createLinearGradient(x, y, x, GROUND);
  grd.addColorStop(0, color);
  grd.addColorStop(1, "rgba(255,200,230,0.7)");
  ctx.fillStyle = grd;

  // Rounded rect
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h);
  ctx.lineTo(x, y + h);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
  ctx.fill();

  // "!" label
  ctx.fillStyle   = "rgba(255,255,255,0.8)";
  ctx.font        = "bold 13px Arial";
  ctx.textAlign   = "center";
  ctx.fillText("!", x + w / 2, GROUND - h / 2 + 5);

  // Soft shadow under obstacle
  ctx.fillStyle = "rgba(200,100,180,0.18)";
  ctx.beginPath();
  ctx.ellipse(x + w / 2, GROUND + 3, w / 2 + 2, 5, 0, 0, Math.PI * 2);
  ctx.fill();
}

// ── FRUITS ───────────────────────────────────────────────────

function drawFruit(ctx, f) {
  f.bob += 0.06;
  const by = f.y + Math.sin(f.bob) * 7;

  ctx.font      = "22px serif";
  ctx.textAlign = "center";
  ctx.fillText(f.emoji, f.x, by);

  // Pulsing glow ring
  ctx.save();
  ctx.globalAlpha  = 0.35 + Math.sin(f.bob) * 0.15;
  ctx.strokeStyle  = f.color;
  ctx.lineWidth    = 2.5;
  ctx.beginPath();
  ctx.arc(f.x, by - 8, 14, 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();
}
